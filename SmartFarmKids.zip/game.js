var config = { type: Phaser.AUTO, width: 900, height: 600, backgroundColor: "#d8f3dc", scene: { preload: preload, create: create, update: update } };
var game = new Phaser.Game(config);
function preload() {
  this.load.image('farm', 'https://i.imgur.com/3ZQ3ZFm.png');
  this.load.image('plant', 'https://i.imgur.com/0V3QFQf.png');
  this.load.image('water', 'https://i.imgur.com/vUXL7Yr.png');
}
function create() {
  this.add.text(280, 20, "SmartFarm Kids", { font: "40px Arial", fill: "#1b4332" });
  var farm = this.add.image(450, 350, 'farm').setScale(0.7);
  var plant = this.add.sprite(450, 350, 'plant').setScale(0.5).setInteractive();
  var waterBtn = this.add.image(800, 520, 'water').setScale(0.3).setInteractive();
  this.add.text(750, 550, "Water", { font: "20px Arial", fill: "#1b4332" });
  waterBtn.on('pointerdown', function () { plant.setTint(0x88cc88); });
}
function update() {}
